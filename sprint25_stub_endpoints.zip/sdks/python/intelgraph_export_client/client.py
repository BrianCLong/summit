from __future__ import annotations
import httpx
from typing import Any, Dict

class ExportClient:
    def __init__(self, base_url: str, headers: Dict[str,str] | None = None, timeout: float = 5.0):
        self.base_url = base_url.rstrip('/')
        self.headers = {"content-type":"application/json", **(headers or {})}
        self.timeout = timeout

    def _post(self, path: str, payload: dict) -> dict:
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(f"{self.base_url}{path}", json=payload, headers=self.headers)
            resp.raise_for_status()
            return resp.json()

    def simulate(self, input: dict) -> dict:
        return self._post("/export/simulate", input)

    def enforce(self, input: dict) -> dict:
        return self._post("/export", input)
