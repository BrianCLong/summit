export type Decision = {
  effect: 'allow' | 'deny' | 'step_up' | 'allow_with_redactions';
  redact_fields: string[];
  reasons: string[];
  simulated: boolean;
  note?: string;
};

export interface ClientOptions {
  baseUrl: string; // e.g., http://localhost:8080
  fetchImpl?: typeof fetch;
  headers?: Record<string, string>;
}

export class ExportClient {
  private baseUrl: string;
  private fetchImpl: typeof fetch;
  private headers: Record<string,string>;

  constructor(opts: ClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/$/, '');
    this.fetchImpl = opts.fetchImpl || fetch;
    this.headers = { 'content-type': 'application/json', ...(opts.headers || {}) };
  }

  async simulate(input: any): Promise<Decision> {
    const r = await this.fetchImpl(`${this.baseUrl}/export/simulate`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(input)
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json() as Decision;
  }

  async enforce(input: any): Promise[Decision> {
    const r = await this.fetchImpl(`${this.baseUrl}/export`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify(input)
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json() as Decision;
  }
}
