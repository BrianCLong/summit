# FastAPI Export Gateway

Run locally:
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8081
curl -s localhost:8081/export/simulate -H 'content-type: application/json' -d @../../tests/sample_input.json | jq .
```
