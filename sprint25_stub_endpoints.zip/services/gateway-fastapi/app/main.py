from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import os, httpx

class FieldItem(BaseModel):
    name: str
    labels: Optional[List[str]] = []

class Bundle(BaseModel):
    id: str
    sensitivity: str
    fields: List[FieldItem]

class User(BaseModel):
    id: str
    roles: List[str]
    permissions: Optional[List[str]] = []
    tenant: Optional[str] = None

class Options(BaseModel):
    dlp_mask_fields: Optional[List[str]] = []

class DecisionInput(BaseModel):
    user: User
    action: str = Field("export", pattern="^export$")
    bundle: Bundle
    options: Options = Options()
    webauthn_verified: bool = False
    simulate: bool = False

class Decision(BaseModel):
    effect: str
    redact_fields: List[str] = []
    reasons: List[str] = []
    simulated: bool = False
    note: Optional[str] = ""

OPA_URL = os.getenv("OPA_URL", "http://localhost:8181/v1/data/export/decision")

app = FastAPI(title="IntelGraph Export Gateway")

async def call_opa(payload: dict) -> dict:
    async with httpx.AsyncClient(timeout=5.0) as client:
        r = await client.post(OPA_URL, json={"input": payload})
        r.raise_for_status()
        data = r.json()
        return data.get("result", data)

def sanitize(decision: dict, simulated: Optional[bool] = None) -> Decision:
    d = Decision(
        effect=decision.get("effect", "deny"),
        redact_fields=decision.get("redact_fields", []) or [],
        reasons=decision.get("reasons", []) or ["unspecified"],
        simulated=decision.get("simulated", False),
        note=decision.get("note", ""),
    )
    if simulated is not None:
        d.simulated = simulated
    return d

@app.post("/export/simulate", response_model=Decision)
async def simulate(input: DecisionInput):
    try:
        decision = await call_opa({**input.model_dump(), "simulate": True})
        return sanitize(decision, simulated=True)
    except Exception as e:
        return sanitize({
            "effect": "allow_with_redactions",
            "redact_fields": [],
            "reasons": ["simulation_fallback"],
            "note": f"OPA unreachable: {e}"
        }, simulated=True)

@app.post("/export", response_model=Decision)
async def enforce(input: DecisionInput):
    try:
        decision = await call_opa({**input.model_dump(), "simulate": False})
        return sanitize(decision)
    except Exception as e:
        return sanitize({
            "effect": "deny",
            "redact_fields": [],
            "reasons": ["opa_unreachable"],
            "note": f"OPA unreachable: {e}"
        }, simulated=False)
