# Express Export Gateway

Simple wrapper exposing `/export` and `/export/simulate` and delegating decisions to OPA `export/decision`.
- Env: `OPA_URL` (default `http://localhost:8181/v1/data/export/decision`), `PORT` (default 8080).

```bash
npm i
npm run start
# In another shell:
curl -s localhost:8080/export/simulate -H 'content-type: application/json' -d @../../tests/sample_input.json | jq .
```
