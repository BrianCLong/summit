import fetch from 'node-fetch';

const OPA_URL = process.env.OPA_URL || 'http://localhost:8181/v1/data/export/decision';

/**
 * Calls OPA with input and returns the decision object.
 */
export async function evaluateDecision(input) {
  const r = await fetch(OPA_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ input })
  });
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`OPA error ${r.status}: ${text}`);
  }
  const data = await r.json();
  // Expect data.result to be the policy object
  return data.result || data;
}
