import { evaluateDecision } from './opaClient.js';

const sample = {
  simulate: true,
  user: { id: 'u1', roles: ['exporter'], permissions: ['export'], tenant: 'acme' },
  action: 'export',
  webauthn_verified: false,
  bundle: {
    id: 'b1',
    sensitivity: 'Sensitive',
    fields: [
      { name: 'email', labels: ['pii:email'] },
      { name: 'name', labels: [] }
    ]
  },
  options: { dlp_mask_fields: [] }
};

evaluateDecision(sample).then(d => {
  console.log('Decision:', d);
}).catch(err => {
  console.error('OPA call failed (expected in self-test unless OPA running):', err.message);
});
