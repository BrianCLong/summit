import express from 'express';
import { evaluateDecision } from './opaClient.js';
import pino from 'pino';

const app = express();
const log = pino({ level: process.env.LOG_LEVEL || 'info' });

app.use(express.json({ limit: '2mb' }));

function sanitizeDecision(decision) {
  // Ensure required fields exist
  return {
    effect: decision.effect || 'deny',
    redact_fields: decision.redact_fields || [],
    reasons: decision.reasons || ['unspecified'],
    simulated: !!decision.simulated,
    note: decision.note || ''
  };
}

app.post('/export/simulate', async (req, res) => {
  try {
    const input = { ...req.body, simulate: true };
    const decision = await evaluateDecision(input);
    res.json(sanitizeDecision({ ...decision, simulated: true }));
  } catch (err) {
    log.error({ err }, 'simulate_failed');
    res.status(200).json(sanitizeDecision({
      effect: 'allow_with_redactions',
      redact_fields: [],
      reasons: ['simulation_fallback'],
      simulated: true,
      note: 'OPA unreachable; simulation fallback'
    }));
  }
});

app.post('/export', async (req, res) => {
  try {
    const input = { ...req.body, simulate: false };
    const decision = await evaluateDecision(input);
    res.json(sanitizeDecision(decision));
  } catch (err) {
    log.error({ err }, 'enforce_failed');
    res.status(200).json(sanitizeDecision({
      effect: 'deny',
      redact_fields: [],
      reasons: ['opa_unreachable'],
      simulated: false,
      note: 'OPA unreachable; default deny'
    }));
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  log.info({ port }, 'export-gateway-up');
});
