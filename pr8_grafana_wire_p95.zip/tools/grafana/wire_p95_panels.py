#!/usr/bin/env python3
import json, sys, re, pathlib

def main():
    if len(sys.argv) < 3:
        print("Usage: wire_p95_panels.py <path/to/ga_core_dashboard.json> <path/to/ga_core_dashboard.json.patch> [output.json]")
        sys.exit(1)
    in_path = sys.argv[1]
    patch_path = sys.argv[2]
    out_path = sys.argv[3] if len(sys.argv) > 3 else in_path

    with open(in_path, 'r') as f:
        dashboard = json.load(f)
    with open(patch_path, 'r') as f:
        patch = json.load(f)

    # Ensure panels array exists
    if "panels" not in dashboard or not isinstance(dashboard["panels"], list):
        dashboard["panels"] = []

    # Apply minimal patch operations we emit: add to /panels/-
    for op in patch:
        if op.get("op") != "add" or not op.get("path", "").startswith("/panels"):
            print(f"Skipping unsupported op: {op}")
            continue
        # only support /panels/- or /panels/<index>
        path = op["path"]
        if path not in ("/panels/-", "/panels"):
            m = re.match(r"^/panels/(\d+)$", path)
            if not m:
                print(f"Unsupported path: {path}; skipping")
                continue
            idx = int(m.group(1))
            dashboard["panels"].insert(idx, op["value"])
        else:
            dashboard["panels"].append(op["value"])

    # Recompute unique IDs to avoid collisions if present
    # Grafana panels often have 'id' fields; if so, set to max+1 incrementally
    next_id = 1
    for p in dashboard["panels"]:
        if isinstance(p, dict) and "id" in p:
            try:
                next_id = max(next_id, int(p["id"]) + 1)
            except Exception:
                pass
    for p in dashboard["panels"]:
        if isinstance(p, dict) and "id" not in p:
            p["id"] = next_id
            next_id += 1

    with open(out_path, 'w') as f:
        json.dump(dashboard, f, indent=2)
    print(f"Wrote merged dashboard to {out_path}")

if __name__ == "__main__":
    main()
