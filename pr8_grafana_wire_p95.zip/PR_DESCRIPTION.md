# feat(grafana): wire p95 panels into GA Core dashboard

This PR adds **Preview p95** and **Execute p95** panels to the existing `ga_core_dashboard.json` using a minimal JSON Patch and a helper script, preserving your current layout, variables, and provisioning.

## Files
- `grafana/dashboards/ga_core_dashboard.json.patch` – JSON Patch with two new panels
- `tools/grafana/wire_p95_panels.py` – tiny helper to apply the patch
- `grafana/panels/p95_preview.json`, `grafana/panels/p95_execute.json` – source panels (copied from PR #6)
- `grafana/README.md` – usage + drilldowns

## Usage
```bash
git checkout -b feat/grafana-wire-p95
python3 tools/grafana/wire_p95_panels.py grafana/dashboards/ga_core_dashboard.json grafana/dashboards/ga_core_dashboard.json.patch
git add grafana/dashboards/ga_core_dashboard.json
git commit -m "feat(grafana): wire p95 panels into GA Core dashboard"
```

## Why JSON Patch?
- Avoids overwriting any changes you already made to the dashboard.
- Easy to diff and review; panels are appended to `panels[]` with sensible defaults.

## Notes
- If your dashboard organizes panels under rows, this still works (Grafana flattens `panels[]` for many layouts). If you use nested `gridPos` within rows, you can re-position after import.
- The panels respect `${env}` and `${tenant}` variables if present; otherwise they default to raw metrics.
