# Grafana: GA Core Dashboard (wired with p95 panels)

This PR wires the **Preview p95** and **Execute p95** panels into the existing **GA Core** dashboard _without_ altering your variables or existing panels.

## What changed

- Added two panels to `panels[]` via a small JSON Patch:
  - `Preview p95` (left)
  - `Execute p95` (right)
- Panels source their queries from Prometheus and respect existing dashboard variables (`env`, `tenant`).

## How to apply in-repo

From the repo root (assuming your dashboard is at `grafana/dashboards/ga_core_dashboard.json`):

```bash
python3 tools/grafana/wire_p95_panels.py grafana/dashboards/ga_core_dashboard.json grafana/dashboards/ga_core_dashboard.json.patch
```

Commit the updated JSON afterwards.

> Tip: If you provision dashboards via ConfigMap or file provider, just commit the modified JSON and let your pipeline roll it out.

## Drilldowns & Links

- The dashboard README now links to the **p95 demo harness** and **verify-bundle** CLI for the Day-6 demo.
- See also: `tools/p95/` and `docs/runbooks/p95-demo.md` (from PR #6).

## Datasource

Set your Prometheus datasource UID via `${DS_PROMETHEUS}` or update the panels after import.

