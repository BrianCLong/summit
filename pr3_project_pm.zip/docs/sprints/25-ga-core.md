---
title: Sprint 25 — GA Core
---
## Mid-sprint demo targets
- Adjudication queue merge
- verify-bundle CLI round-trip
- p95 preview ≤1.5s / exec ≤3.5s
