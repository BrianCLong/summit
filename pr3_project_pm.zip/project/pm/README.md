# Jira Import
Use Jira → System → External System Import → CSV. Map Parent/Epic/External ID; Sprint = "Sprint 25".
