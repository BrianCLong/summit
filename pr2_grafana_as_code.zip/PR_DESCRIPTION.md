# feat(grafana): provision GA Core dashboard via code
Adds dashboard JSON, provisioning, and K8s ConfigMap.
