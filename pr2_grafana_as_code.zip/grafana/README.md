# Grafana — GA Core Dashboard

Import via UI or provision via file/K8s. Variables: `env`, `tenant`.
