---
title: Export API (simulate & enforce)
summary: Endpoints to simulate and enforce export decisions.
owner: devsec
lastUpdated: 2025-09-17
version: sprint-25
---
# Export API
- `POST /export/simulate` — dry-run decision payload.
- `POST /export` — enforce decision (deny/redact/step-up).
