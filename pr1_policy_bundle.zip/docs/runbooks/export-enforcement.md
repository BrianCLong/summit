---
title: Runbook — Export Policy
owner: sre
lastUpdated: 2025-09-17
version: sprint-25
---
1) Simulate for 2 days. 2) Monitor. 3) Enforce. 4) Rollback if needed.
