# Policies — Export
Local test:
```bash
opa test -v .
```
