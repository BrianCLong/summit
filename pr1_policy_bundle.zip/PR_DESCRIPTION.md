# feat(policies): add export.rego + OPA CI
Adds policy, smoke tests, CI, and minimal docs.
