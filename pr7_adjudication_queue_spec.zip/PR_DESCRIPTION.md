docs(spec): add adjudication queue spec, OpenAPI draft, wireframes, ADR
