# Wireframe notes
- List + Detail + Audit
