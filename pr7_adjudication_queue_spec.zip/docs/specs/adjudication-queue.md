---
title: Adjudication Queue — Spec (Undo + Audit)
lastUpdated: 2025-09-17
owner: Product + BE
status: draft
---

Provide a queue for export decisions requiring human review. Supports **undo** and immutable audit.

## API (draft)
- POST /adjudications
- GET /adjudications?state=pending
- POST /adjudications/{id}/decision
- POST /adjudications/{id}/undo
- GET /adjudications/{id}/audit

## State
```mermaid
stateDiagram-v2
    [*] --> pending
    pending --> shipped: allow
    pending --> shipped: redact
    pending --> denied: deny
    shipped --> pending: undo (≤ window)
    denied --> pending: undo (≤ window)
```
