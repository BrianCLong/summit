# ADR-012: Append-only audit for adjudication
Decision: store DecisionEvent log in relational DB.
