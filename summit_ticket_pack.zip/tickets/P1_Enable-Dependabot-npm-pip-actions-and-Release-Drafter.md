# Enable Dependabot (npm, pip, actions) and Release Drafter
**Priority:** P1  
**Owner:** (assign)  
**ETA:** (estimate)  
**Dependencies:** (list)  

## Context
Automate dependency updates and changelog/version drafting.

## Acceptance Criteria
- [ ] All checks pass in CI
- [ ] Documentation updated
- [ ] Security gates enforced
- [ ] No regressions in critical paths

## Implementation Steps
- [ ] (fill in sub-tasks)
