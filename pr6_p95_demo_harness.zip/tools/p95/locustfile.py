import os, csv, random
from locust import HttpUser, task, between, events

BASE_URL = os.environ.get("BASE_URL","http://localhost:8080").rstrip("/")
TENANT = os.environ.get("TENANT","demo")
ENV = os.environ.get("ENV","dev")

SAMPLES = ["top 10 products by revenue last month","daily active users by region","errors by service last 24h"]
csv_path = os.path.join(os.path.dirname(__file__), "samples", "queries.csv")
if os.path.exists(csv_path):
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        SAMPLES = [r["query"] for r in reader if r.get("query")] or SAMPLES

class IG(HttpUser):
    wait_time = between(0.5, 2.0)

    @task(3)
    def preview(self):
        q = random.choice(SAMPLES)
        payload = {"query": q, "tenant": TENANT, "env": ENV, "dryRun": True}
        self.client.post(f"{BASE_URL}/nlq/preview", json=payload, name="nlq_preview")

    @task(1)
    def execute(self):
        q = random.choice(SAMPLES)
        payload = {"query": q, "tenant": TENANT, "env": ENV, "timeoutMs": 10000}
        self.client.post(f"{BASE_URL}/nlq/execute", json=payload, name="nlq_execute")

@events.quitting.add_listener
def dump_stats(env, **_):
    try:
        rows = [["metric","count","p95_seconds"]]
        for s in env.stats.entries.values():
            if s.num_requests:
                p95 = s.get_response_time_percentile(0.95)/1000.0
                rows.append([s.name, s.num_requests, f"{p95:.3f}"])
        with open("p95_stats.csv","w") as f:
            for r in rows: f.write(",".join(map(str,r))+"\n")
        print("Wrote p95_stats.csv")
    except Exception as e:
        print("Failed to write p95_stats.csv:", e)
