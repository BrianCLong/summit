#!/usr/bin/env bash
set -euo pipefail
: "${BASE_URL:=http://localhost:8080}"
hey -z 60s -c ${C:-50} -q 10 -m POST -H "Content-Type: application/json"   -d '{"query":"top 10 products by revenue last month","tenant":"demo","env":"dev","dryRun":true}'   "${BASE_URL}/nlq/preview"
