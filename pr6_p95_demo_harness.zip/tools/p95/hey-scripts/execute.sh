#!/usr/bin/env bash
set -euo pipefail
: "${BASE_URL:=http://localhost:8080}"
hey -z 60s -c ${C:-30} -q 5 -m POST -H "Content-Type: application/json"   -d '{"query":"daily active users by region","tenant":"demo","env":"dev","timeoutMs":10000}'   "${BASE_URL}/nlq/execute"
