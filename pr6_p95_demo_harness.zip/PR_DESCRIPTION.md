feat(demo): add p95 demo harness (Locust + hey) and Grafana panel JSON
