# p95 Demo Harness (NLQ preview & execute)
lastUpdated: 2025-09-17
owner: SRE + BE

Minimal Locust/hey harness to measure p95 for:
- `POST /nlq/preview` (≤ 1.5s)
- `POST /nlq/execute` (≤ 3.5s)

## Locust
```
pip install locust==2.31.2 requests
export BASE_URL=http://localhost:8080 USERS=50 SPAWN_RATE=10 DURATION=300
locust -f tools/p95/locustfile.py --headless -u $USERS -r $SPAWN_RATE -t ${DURATION}s --csv p95
```
Outputs `p95_stats.csv` at shutdown.
