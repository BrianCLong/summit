## Summary
<!-- What does this PR change? -->

## Checklist
- [ ] CI green (PR CI)
- [ ] If touching workflows, ran `./scripts/ci_repair_pack.sh` locally (optional)
- [ ] Tests added/updated (if applicable)
- [ ] Docs updated (if applicable)

## Risks
<!-- Rollback plan / toggles -->
