# CI Baseline & Governance

This pack adds:
- **Reusable CI** workflow (`_reusable-ci.yml`) for Node/pnpm projects
- **PR CI / Push CI** that call the reusable workflow
- **PR Labeler** and label config
- **Dependabot** for npm, docker, and GitHub Actions
- **OpenSSF Scorecard** with SARIF upload
- **CODEOWNERS**, PR template, issue templates
- **Branch protection helper** (`scripts/apply_branch_protection.sh`)

## Quick start
```bash
git switch -c chore/ci-baseline
cp -R .github/ scripts/ docs/ <repo-root>/
git add .github scripts docs
git commit -m "ci: baseline & governance (reusable ci, labeler, dependabot, scorecard)"
git push -u origin chore/ci-baseline
```

Then run:
```bash
bash scripts/apply_branch_protection.sh  # requires gh + GH_TOKEN with admin perms
```
