#!/usr/bin/env bash
# Apply branch protection for main using GitHub CLI.
# Requires: GH_TOKEN with repo:admin, and gh CLI installed.
set -euo pipefail

BRANCH=${1:-main}
OWNER_REPO=$(git config --get remote.origin.url | sed -E 's#(git@|https://)github.com[:/](.*)\.git#\2#')
REPO="${OWNER_REPO##*/}"
OWNER="${OWNER_REPO%/*}"

echo "Applying protection to $OWNER/$REPO:$BRANCH"

# Enable required status checks (adjust list as needed)
REQUIRED_CONTEXTS='["PR CI / webapp","OpenSSF Scorecard / analysis","Code Scanning - CodeQL / Analyze","Container Security / trivy"]'

gh api -X PUT repos/$OWNER/$REPO/branches/$BRANCH/protection   -f required_status_checks.strict=true   -F required_status_checks.contexts="$REQUIRED_CONTEXTS"   -f enforce_admins=true   -F required_pull_request_reviews='{"required_approving_review_count": 1, "require_code_owner_reviews": true}'   -F restrictions='null'   -f required_linear_history=true   -f allow_force_pushes=false   -f allow_deletions=false

echo "Branch protection applied."
