# Security Policy

- Report vulnerabilities via [SECURITY.md contact or platform].
- Do not file public issues for vulnerabilities.
- Supported branches: main
