---
name: Feature request
about: Suggest an idea
labels: enhancement, needs-triage
---

**Problem**
**Proposed solution**
**Alternatives**
**Impact (users/teams/metrics)**
**Effort estimate (S/M/L)**
