# IntelGraph GA - Go/No-Go Dashboard

| Metric                               | Target | Current | Status | Notes |
| ------------------------------------ | ------ | ------- | ------ | ----- |
| **ER Precision@k**                   | >95%   | TBD     | 🔴     |       |
| **ER Explainability Coverage**       | >98%   | TBD     | 🔴     |       |
| **RAG Citation Hit-Rate**            | >90%   | TBD     | 🔴     |       |
| **Audit Coverage**                   | 100%   | TBD     | 🔴     |       |
| **Policy-Block Explainability Rate** | >99%   | TBD     | 🔴     |       |
