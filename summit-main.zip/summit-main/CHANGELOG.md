## [v24.0.0] — 2025‑09‑08
### Added
- Global Coherence Ecosystem (API, subscriptions, metrics, policy, CI/CD gates)
- Prometheus alerts and Grafana dashboard excerpt
- Evidence bundle generation in CI
### Changed
- PubSub upgraded to Redis‑backed with in‑memory fallback
### Fixed
- N/A