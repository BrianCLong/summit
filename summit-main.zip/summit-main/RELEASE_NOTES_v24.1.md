**Release:** v24.1 — Hardening & Operations
**Date:** 2025‑__‑__

## Highlights
- Ingest reliability & idempotency hooks
- Redis caching + RPS limiter
- Residency guard + fine‑grained scopes
- Subscription latency metric; trace sampling

## SLO Validation
- Read p95: ____  Write p95: ____  Error‑rate: ____  Sub p95: ____  Ingest p95: ____

## Ops Notes
- Feature flags unchanged; same rollback path as v24.0.0
