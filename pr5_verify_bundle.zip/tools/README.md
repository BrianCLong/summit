# Tools

- `verify-bundle` — verify release bundle checksums
