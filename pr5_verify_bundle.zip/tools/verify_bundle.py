#!/usr/bin/env python3
"""
verify_bundle.py — simple artifact hashing and verification utility

Features:
- Compute and verify SHA-256/512 checksum for a bundle (zip/tar/any file).
- Looks for a companion .sha256/.sha512 file by default, or specify via --sha.
- Optional: --write to create/update the companion checksum file.
- Optional: --json for machine-friendly output.
- Optional: --expect to assert that bundle filenames match regexes (zip/tar only).
"""
import argparse, hashlib, os, sys, json, re, zipfile, tarfile
from typing import List, Dict, Optional, Tuple

def compute_hash(path: str, algo: str="sha256") -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def guess_sha_file(bundle: str, algo: str) -> str:
    ext = ".sha256" if algo == "sha256" else ".sha512"
    return bundle + ext

def parse_sha_file(path: str) -> Tuple[str, Optional[str]]:
    """
    Returns (hash, filename) read from a standard checksum line: "<hash>  <filename>"
    filename may be None if not present.
    """
    with open(path, "r") as f:
        line = f.readline().strip()
    if not line:
        raise ValueError("Empty checksum file")
    parts = line.split()
    if len(parts) == 1:
        return parts[0], None
    else:
        return parts[0], parts[-1]

def list_bundle_members(bundle: str) -> List[str]:
    members = []
    if zipfile.is_zipfile(bundle):
        with zipfile.ZipFile(bundle, "r") as z:
            members = z.namelist()
    elif tarfile.is_tarfile(bundle):
        with tarfile.open(bundle, "r:*") as t:
            members = [m.name for m in t.getmembers() if m.isfile()]
    return members

def main(argv=None):
    p = argparse.ArgumentParser(description="Verify or write checksum for a bundle")
    p.add_argument("bundle", help="Path to bundle file (zip/tar/any file)")
    p.add_argument("--algo", choices=["sha256","sha512"], default="sha256")
    p.add_argument("--sha", dest="sha_path", help="Path to checksum file (.sha256/.sha512)")
    p.add_argument("--write", action="store_true", help="Write companion checksum file")
    p.add_argument("--json", dest="as_json", action="store_true", help="JSON output")
    p.add_argument("--expect", action="append", default=[],
                   help="Regex of expected member (repeatable). Applies to zip/tar bundles.")
    args = p.parse_args(argv)

    bundle = args.bundle
    if not os.path.isfile(bundle):
        print(f"ERROR: bundle not found: {bundle}", file=sys.stderr)
        return 2

    algo = args.algo
    digest = compute_hash(bundle, algo=algo)
    sha_path = args.sha_path or guess_sha_file(bundle, algo)
    ok = None
    ref_hash = None
    ref_filename = None
    error = None

    if args.write:
        with open(sha_path, "w") as f:
            f.write(f"{digest}  {os.path.basename(bundle)}\n")

    if os.path.exists(sha_path):
        try:
            ref_hash, ref_filename = parse_sha_file(sha_path)
            ok = (digest.lower() == ref_hash.lower())
        except Exception as e:
            error = f"failed to parse checksum file: {e}"
            ok = False
    else:
        ok = None  # no reference to compare

    # Optional expected members
    members = list_bundle_members(bundle)
    expect_ok = True
    missing = []
    if args.expect:
        for pat in args.expect:
            pattern = re.compile(pat)
            if not any(pattern.search(m) for m in members):
                expect_ok = False
                missing.append(pat)

    status = 0
    if ok is False or expect_ok is False:
        status = 1

    if args.as_json:
        out = {
            "bundle": os.path.abspath(bundle),
            "algo": algo,
            "digest": digest,
            "shaFile": os.path.abspath(sha_path),
            "hasRef": os.path.exists(sha_path),
            "matches": ok,
            "refFilename": ref_filename,
            "isArchive": bool(members),
            "membersChecked": bool(args.expect),
            "expectOk": expect_ok,
            "missingMatchers": missing,
            "error": error,
        }
        print(json.dumps(out, indent=2))
    else:
        print(f"{algo.upper()}  {digest}  {bundle}")
        if ok is True:
            print(f"OK: matches {sha_path}")
        elif ok is False:
            print(f"FAIL: does not match {sha_path}")
        else:
            print(f"NOTE: no checksum file found at {sha_path}")
        if args.expect:
            if expect_ok:
                print("OK: all expected patterns present")
            else:
                print("FAIL: missing expected patterns:", ", ".join(missing))
        if error:
            print(f"ERROR: {error}", file=sys.stderr)

    return status

if __name__ == "__main__":
    sys.exit(main())
