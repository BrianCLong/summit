---
title: verify-bundle CLI
summary: Hash and verify release bundles for round-trip proof (hash match).
owner: DevEx
lastUpdated: 2025-09-17
---

# verify-bundle

`verify-bundle` computes and validates checksums for release bundles (zip/tar/any file)
and (optionally) asserts that expected files are present inside the archive.

## Install

```bash
# repo root
chmod +x tools/verify-bundle
```

## Quick start

```bash
# Write checksum
tools/verify-bundle sprint25_day1_artifacts.zip --write

# Verify against companion checksum
tools/verify-bundle sprint25_day1_artifacts.zip

# Machine-readable
tools/verify-bundle sprint25_day1_artifacts.zip --json

# Verify and assert members (zip/tar only)
tools/verify-bundle sprint25_day1_artifacts.zip \
  --expect 'sprint25_jira\.csv' \
  --expect 'export\.rego' \
  --expect 'grafana_ga_core_dashboard\.json'
```

## Exit codes

- `0` success (hash matches and expectations satisfied)
- `1` mismatch (hash mismatch or expected files missing)
- `2` usage error (bundle not found, etc.)

## CI example (GitHub Actions)

```yaml
name: verify-bundle
on:
  pull_request:
  push:
jobs:
  verify:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.x'
      - name: Verify fixture
        run: |
          python3 tools/verify_bundle.py fixtures/hello.zip --sha fixtures/hello.zip.sha256
```
