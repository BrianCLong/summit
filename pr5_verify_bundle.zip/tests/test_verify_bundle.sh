#!/usr/bin/env bash
set -euo pipefail
python3 tools/verify_bundle.py fixtures/hello.zip --sha fixtures/hello.zip.sha256 >/dev/null
echo "OK"
