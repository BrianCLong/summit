# feat(cli): add verify-bundle round-trip proof

Adds a small CLI + CI to compute and verify checksums for release bundles.

## Highlights
- `tools/verify-bundle` wrapper + `tools/verify_bundle.py` implementation
- Companion checksum files: `.sha256` / `.sha512`
- `--write` to author checksum, `--json` for machine output
- Optional `--expect` regex checks for archive contents (zip/tar)
- CI workflow runs verification on a small fixture

## Usage
```bash
# write checksum beside your bundle
tools/verify-bundle sprint25_day1_artifacts.zip --write

# verify later (or on another host)
tools/verify-bundle sprint25_day1_artifacts.zip

# strict: confirm expected files are present
tools/verify-bundle sprint25_day1_artifacts.zip \
  --expect 'sprint25_jira\.csv' --expect 'export\.rego' --expect 'grafana_ga_core_dashboard\.json'
```

## Notes
- No external dependencies; pure Python 3.
- Works with any file; content assertions are supported for zip/tar archives only.
