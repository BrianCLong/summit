# ci: add docs-required gate (policies/ & grafana/)

- Adds a PR check that fails if changes in `policies/` or `grafana/` land without docs updates.
- Includes a commented `CODEOWNERS` template to configure reviews later.

> Update `CODEOWNERS` with real team handles in a follow-up.
